'use client'

import ShaderBackground from '@/components/ShaderBackground'
import TopNavBar from '@/components/TopNavBar'
import HeroSection from '@/components/HeroSection'
import CoreServices from '@/components/CoreServices'
import ProductionWorkflow from '@/components/ProductionWorkflow'
import CTASection from '@/components/CTASection'
import Footer from '@/components/Footer'
import { useEffect } from 'react'

export default function Page() {
  useEffect(() => {
    // Reveal animation on scroll
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px',
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active')
        }
      })
    }, observerOptions)

    document.querySelectorAll('.reveal-up').forEach((el) => observer.observe(el))

    // Parallax effect for cards
    const handleMouseMove = (e: MouseEvent) => {
      const cards = document.querySelectorAll('.glass-panel')
      const mouseX = e.clientX
      const mouseY = e.clientY

      cards.forEach((card) => {
        const rect = card.getBoundingClientRect()
        const cardX = rect.left + rect.width / 2
        const cardY = rect.top + rect.height / 2

        const angleX = (mouseY - cardY) / 50
        const angleY = (mouseX - cardX) / -50

        if (Math.abs(mouseX - cardX) < 400 && Math.abs(mouseY - cardY) < 400) {
          ;(card as HTMLElement).style.transform = `perspective(1000px) rotateX(${angleX}deg) rotateY(${angleY}deg)`
        } else {
          ;(card as HTMLElement).style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg)`
        }
      })
    }

    document.addEventListener('mousemove', handleMouseMove)

    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      observer.disconnect()
    }
  }, [])

  return (
    <>
      <ShaderBackground />
      <TopNavBar />
      <main className="relative z-10 pt-20">
        <HeroSection />
        <CoreServices />
        <ProductionWorkflow />
        <CTASection />
      </main>
      <Footer />
    </>
  )
}
