export default function TopNavBar() {
  return (
    <header className="fixed top-0 w-full z-50 bg-[#121416]/80 backdrop-blur-xl border-b-[0.5px] border-[#594138] shadow-[0_0_15px_rgba(242,100,25,0.2)]">
      <nav className="flex justify-between items-center h-20 px-16 max-w-full">
        <div className="flex items-center">
          <img
            src="/mm-logo.png"
            alt="MM Printing Logo"
            className="h-20 w-20 hover:scale-105 transition-transform duration-300"
          />
        </div>
        <div className="hidden md:flex items-center gap-6">
          <a className="tracking-tight text-[#ffb597] border-b-2 border-[#ffb597] pb-1 transition-colors duration-300" href="#" style={{ fontSize: '24px', fontWeight: 600, lineHeight: '1.4' }}>
            Home
          </a>
          <a className="tracking-tight text-[#e1bfb2] font-medium hover:text-[#ffb597] transition-colors duration-300" href="#" style={{ fontSize: '24px', fontWeight: 500, lineHeight: '1.4' }}>
            Services
          </a>
          <a className="tracking-tight text-[#e1bfb2] font-medium hover:text-[#ffb597] transition-colors duration-300" href="#" style={{ fontSize: '24px', fontWeight: 500, lineHeight: '1.4' }}>
            Contact
          </a>
        </div>
        <button className="bg-[#f26419] text-[#4e1900] px-6 py-3 rounded-none hover:shadow-[0_0_20px_rgba(242,100,25,0.4)] active:scale-95 transition-all duration-300" style={{ fontSize: '12px', fontWeight: 700, lineHeight: '1', letterSpacing: '0.1em' }}>
          Initialize Project
        </button>
      </nav>
    </header>
  )
}
