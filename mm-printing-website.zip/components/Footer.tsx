export default function Footer() {
  return (
    <footer className="w-full relative overflow-hidden border-t-[0.5px] border-[#594138] bg-[#0c0e10]">
      <div className="grid grid-cols-12 gap-6 px-16 py-12 max-w-7xl mx-auto">
        <div className="col-span-12 md:col-span-4">
          <div className="flex items-center gap-3 mb-6">
            <img
              src="/mm-logo.png"
              alt="MM Printing Logo"
              className="h-10 w-10"
            />
            <div className="text-[#ffb4a9]" style={{ fontSize: '12px', fontWeight: 700, lineHeight: '1', letterSpacing: '0.1em' }}>
              KINETIC PRECISION INDUSTRIES
            </div>
          </div>
          <p className="text-[#e1bfb2] max-w-xs" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            Leading the industrial printing evolution since 1994. Advanced mobile deployments and precision engineering.
          </p>
        </div>

        <div className="col-span-6 md:col-span-4 flex flex-col gap-3">
          <div className="text-[#ffb597] mb-1" style={{ fontSize: '12px', fontWeight: 700, lineHeight: '1', letterSpacing: '0.1em' }}>
            NAV_LINKS
          </div>
          <a className="text-[#e1bfb2] hover:text-[#950c09] transition-all" href="#" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            Operational Status
          </a>
          <a className="text-[#e1bfb2] hover:text-[#950c09] transition-all" href="#" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            Technical Specs
          </a>
          <a className="text-[#e1bfb2] hover:text-[#950c09] transition-all" href="#" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            Privacy Protocol
          </a>
          <a className="text-[#e1bfb2] hover:text-[#950c09] transition-all" href="#" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            Terminal Access
          </a>
        </div>

        <div className="col-span-6 md:col-span-4">
          <div className="text-[#ffb597] mb-1" style={{ fontSize: '12px', fontWeight: 700, lineHeight: '1', letterSpacing: '0.1em' }}>
            CONTACT
          </div>
          <div className="text-[#e1bfb2] mb-3" style={{ fontSize: '14px', fontWeight: 500, lineHeight: '1.4' }}>
            LOC: [34.0522, -118.2437]
            <br />
            TEL: +1-800-KINETIC
          </div>
          <div className="flex gap-6">
            <span className="material-symbols-outlined text-[#e1bfb2] cursor-pointer hover:text-[#ffb597] transition-colors">
              share
            </span>
            <span className="material-symbols-outlined text-[#e1bfb2] cursor-pointer hover:text-[#ffb597] transition-colors">
              rss_feed
            </span>
          </div>
        </div>

        <div className="col-span-12 mt-12 pt-6 border-t border-[#594138]/30 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-[#e1bfb2] opacity-60" style={{ fontSize: '12px', fontWeight: 500, lineHeight: '1.4' }}>
            © 2024 KINETIC PRECISION INDUSTRIES. ALL RIGHTS RESERVED.
          </div>
          <div className="flex gap-6 text-xs" style={{ fontSize: '12px', fontWeight: 500, lineHeight: '1.4', color: '#e1bfb2' }}>
            <span>BUILD: v4.2.0-STABLE</span>
            <span>ENCRYPTION: AES-256</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
